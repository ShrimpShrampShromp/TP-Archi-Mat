void expose( int x );
void exposep( int * x );
int seed( int i );
