void expose( int x );
int seed( int i );
